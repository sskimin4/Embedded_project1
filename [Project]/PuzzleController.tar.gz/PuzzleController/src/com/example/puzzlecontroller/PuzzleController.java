package com.example.puzzlecontroller;

import java.io.FileNotFoundException;
import java.io.IOException;


import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.provider.MediaStore.Images;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

public class PuzzleController extends Activity {
	
	public native void generate_puzzle(int row, int col);
	int r,c;
	public Bitmap image_bitmap;
	final int REQ_CODE_SELECT_IMAGE=100;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
	    System.loadLibrary("puzzlecontroller");
		
		Button buttonGen = (Button) findViewById(R.id.buttonGen);
        buttonGen.setOnClickListener( new OnClickListener() {
        	@SuppressWarnings("deprecation")
			@Override
        	public void onClick(View v) {
                EditText editTextRow = (EditText) findViewById(R.id.editTextRow);
                EditText editTextCol = (EditText) findViewById(R.id.editTextCol);
        		r = Integer.parseInt(editTextRow.getText().toString());
        		c = Integer.parseInt(editTextCol.getText().toString());
        		
        	}
        });
        Button picture = (Button) findViewById(R.id.button2);

		picture.setOnClickListener(new OnClickListener(){
			public void onClick(View v){  // 클릭하면 ACTION_PICK 연결로 기본 갤러리를 불러옵니다.
				Intent intent = new Intent(Intent.ACTION_PICK); 
				intent.setType(android.provider.MediaStore.Images.Media.CONTENT_TYPE);
				intent.setData(android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
				startActivityForResult(intent, REQ_CODE_SELECT_IMAGE); 
			}
		});
		Button btn2=(Button)findViewById(R.id.button3);
		OnClickListener listener=new OnClickListener(){
			public void onClick(View v){
				setContentView(R.layout.activity_main2);
				ImageView image = (ImageView)findViewById(R.id.img1);
				image.setImageBitmap(image_bitmap);
				generate_puzzle(r,c);
			}
		};
		btn2.setOnClickListener(listener);
	}
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) { 
		Toast.makeText(getBaseContext(), "resultCode : "+resultCode,Toast.LENGTH_SHORT).show();
		if(requestCode == REQ_CODE_SELECT_IMAGE){ 
			if(resultCode==Activity.RESULT_OK){     
				try{ 
					//Uri에서 이미지 이름을 얻어온다. 
					//String name_Str = getImageNameToUri(data.getData()); 
					//이미지 데이터를 비트맵으로 받아온다. 
					image_bitmap = Images.Media.getBitmap(getContentResolver(), data.getData());
					//ImageView image = (ImageView)findViewById(R.id.img1); 
					//배치해놓은 ImageView에 set 
					//image.setImageBitmap(image_bitmap);  
					//Toast.makeText(getBaseContext(), "name_Str : "+name_Str , Toast.LENGTH_SHORT).show();
				}catch (FileNotFoundException e){ 
					// TODO Auto-generated catch block 
					e.printStackTrace(); 
				}catch (IOException e){ 
					// TODO Auto-generated catch block 
					e.printStackTrace(); 
				}catch (Exception e){
					e.printStackTrace();
				} 
			}     
		}  
	}
}
